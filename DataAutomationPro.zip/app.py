import json
import logging
import os
from modules.api_client import APIClient
from modules.data_processor import DataProcessor
from modules.google_sheets import GoogleSheetsUploader

# Logging
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename="logs/run.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
console.setFormatter(formatter)
logging.getLogger().addHandler(console)

def load_config(path="config.json"):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    return cfg

def main():
    cfg = load_config()
    logging.info("Loaded config.")
    client = APIClient(cfg.get("api_url"))
    try:
        data = client.fetch()
    except Exception as e:
        logging.error("Failed to fetch data: %s", e)
        return

    processor = DataProcessor()
    try:
        filtered = processor.filter_by_city(data, cfg.get("city"))
    except Exception as e:
        logging.error("Data processing failed: %s", e)
        return

    try:
        processor.save_csv(filtered, cfg.get("output_csv"))
        processor.save_json(filtered, cfg.get("output_json"))
    except Exception as e:
        logging.error("Saving outputs failed: %s", e)
        return

    if cfg.get("use_google_sheets", False):
        url = GoogleSheetsUploader.upload(filtered)
        if url:
            logging.info("Google Sheets URL: %s", url)
        else:
            logging.info("Google Sheets upload not performed or failed.")

    logging.info("Process completed successfully.")

if __name__ == "__main__":
    main()
