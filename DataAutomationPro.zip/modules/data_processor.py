import csv
import json
import os

class DataProcessor:
    @staticmethod
    def filter_by_city(users, city):
        print(f"Filtering by city = '{city}' ...")
        filtered = []
        for u in users:
            city_val = ""
            try:
                city_val = u.get("address", {}).get("city", "")
            except Exception:
                city_val = ""
            if city_val and city_val.lower() == city.lower():
                filtered.append({
                    "id": u.get("id"),
                    "name": u.get("name"),
                    "email": u.get("email"),
                    "city": city_val,
                    "company": u.get("company", {}).get("name", "")
                })
        print(f"Matched records: {len(filtered)}")
        return filtered

    @staticmethod
    def save_csv(rows, path):
        if not rows:
            print("No rows to save to CSV.")
            return
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        fieldnames = ["id","name","email","city","company"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved {len(rows)} rows to CSV: {path}")

    @staticmethod
    def save_json(rows, path):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
        print(f"Saved {len(rows)} rows to JSON: {path}")
