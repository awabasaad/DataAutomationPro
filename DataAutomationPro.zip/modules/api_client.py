import requests

class APIClient:
    def __init__(self, api_url):
        self.api_url = api_url

    def fetch(self, timeout=15):
        """Fetch JSON from API and return Python object (list/dict)."""
        print("Fetching data from API:", self.api_url)
        resp = requests.get(self.api_url, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        print(f"Total records fetched: {len(data)}")
        return data
