import os
from datetime import datetime

def _find_service_account():
    candidates = [
        "service_account.json",
        "/content/drive/My Drive/service_account.json",
        "/content/service_account.json"
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return None

class GoogleSheetsUploader:
    @staticmethod
    def upload(data, sheet_title_base="DataAutomationPro"):
        try:
            sa_path = _find_service_account()
            if not sa_path:
                print("No service_account.json found. Skipping real Google Sheets upload.")
                print("To enable real upload: upload your Service Account JSON to Colab and name it 'service_account.json' or mount Drive with the file present.")
                return None

            import gspread
            from google.oauth2.service_account import Credentials

            scopes = ['https://www.googleapis.com/auth/spreadsheets','https://www.googleapis.com/auth/drive']
            creds = Credentials.from_service_account_file(sa_path, scopes=scopes)
            gc = gspread.authorize(creds)

            timestamp = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
            sheet_title = f"{sheet_title_base} - {timestamp}"
            sh = gc.create(sheet_title)

            ws = sh.get_worksheet(0)
            header = ["id","name","email","city","company"]
            rows = [header]
            for r in data:
                rows.append([r.get(c, "") for c in header])
            ws.update(rows)
            sh.share(None, perm_type='anyone', role='reader')
            url = sh.url
            print(f"Uploaded {len(data)} rows to Google Sheets: {url}")
            return url
        except Exception as e:
            print("Google Sheets upload failed with exception:", str(e))
            return None
