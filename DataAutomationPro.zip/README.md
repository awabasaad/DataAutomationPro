# DataAutomationPro

**DataAutomationPro** — A professional Python automation toolkit that fetches JSON from REST APIs, filters records, and exports results to CSV and JSON. Optionally uploads results to Google Sheets via a Service Account.

## Quick start (Colab)
1. (Optional) Mount Drive if you want to store outputs in Drive.
2. (Optional) Upload `service_account.json` to Colab root to enable real Google Sheets upload.
3. Run:
Outputs: `output/filtered_users.csv`, `output/filtered_users.json`, `logs/run.log`

## Config
Edit `config.json` to change `api_url`, `city`, and output paths.

## Security
Do NOT commit `service_account.json` to public repositories. `.gitignore` excludes it by default.

## License
MIT
